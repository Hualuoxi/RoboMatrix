#ifndef _CODECRAFT_H
#define _CODECRAFT_H

#include "iostream"
#include "strategy.h"

#endif